package app_example.ownDrawMethod;

import com.google.inject.Binder;
import com.google.inject.Module;

public class ScgDemoModule implements Module {

	@Override
	public void configure(Binder arg0) {
		// TODO Auto-generated method stub

	}

}
