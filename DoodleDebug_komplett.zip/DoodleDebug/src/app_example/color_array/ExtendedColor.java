package app_example.color_array;

import java.awt.Color;

public class ExtendedColor extends Color {

	public ExtendedColor(int rgb) {
		super(rgb);
	}

	

}
