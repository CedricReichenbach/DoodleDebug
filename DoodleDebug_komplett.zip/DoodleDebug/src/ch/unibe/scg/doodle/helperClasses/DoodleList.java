package ch.unibe.scg.doodle.helperClasses;

import java.util.ArrayList;

public class DoodleList extends ArrayList<Object> {

}
