package ch.unibe.scg.doodle.helperClasses;

/**
 * Helper class to draw objects even if they're null.
 * 
 * @author Cedric Reichenbach
 * 
 */
public class NullObject {

}
