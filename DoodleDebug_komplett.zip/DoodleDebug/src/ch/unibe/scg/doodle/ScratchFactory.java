package ch.unibe.scg.doodle;

public interface ScratchFactory {
	public Scratch create(Object o);
}
