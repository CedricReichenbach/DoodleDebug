package ch.unibe.scg.doodle;

public class SmallScratch extends RealScratch {

	public SmallScratch(Object o) {
		super(o);
		// TODO Auto-generated constructor stub
	}

}
