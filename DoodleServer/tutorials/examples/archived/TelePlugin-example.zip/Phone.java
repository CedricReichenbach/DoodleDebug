package plugin_example;

public class Phone {

	private int pre;
	private String number;

	public Phone(int pre, String number) {
		this.pre = pre;
		this.number = number;
	}

	public int getPre() {
		return pre;
	}

	public String getNumber() {
		return number;
	}

}
