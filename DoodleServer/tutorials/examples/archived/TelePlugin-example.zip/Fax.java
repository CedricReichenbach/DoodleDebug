package plugin_example;

public class Fax {

	private String number;

	public Fax(String number) {
		this.number = number;
	}

	public String getNumber() {
		return number;
	}

}
